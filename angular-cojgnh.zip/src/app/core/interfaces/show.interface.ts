export interface Show {
  id: string;
  name: string;
  image: string;
  video: string;
}
