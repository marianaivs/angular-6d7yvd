import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../shared/shared.module';

import { ShowCarouselComponent } from './components/show-carousel/show-carousel.component';
import { ShowPosterComponent } from './components/show-poster/show-poster.component';
import { ShowSpotlightComponent } from './components/show-spotlight/show-spotlight.component';
import { FeatureListComponent } from './components/feature-list/feature-list.component';

const COMPONENTS = [FeatureListComponent, ShowCarouselComponent, ShowPosterComponent, ShowSpotlightComponent];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, SharedModule],
  exports: [...COMPONENTS],
})
export class HomeModule {}
