import { Component } from '@angular/core';

@Component({
  selector: 'hero',
  standalone: true,
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.scss'],
})
export class HeroComponent {
  constructor() {}
}
